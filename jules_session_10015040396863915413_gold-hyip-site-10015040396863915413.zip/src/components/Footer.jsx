export default function Footer() {
  return (
    <footer className="bg-black py-12 border-t border-gold/10">
      <div className="mx-auto max-w-7xl px-6 lg:px-8 text-center">
        <div className="flex justify-center space-x-6">
          <a href="#" className="text-gray-400 hover:text-gold transition-colors">Términos y Condiciones</a>
          <a href="#" className="text-gray-400 hover:text-gold transition-colors">Aviso de Privacidad</a>
          <a href="#" className="text-gray-400 hover:text-gold transition-colors">Preguntas Frecuentes</a>
        </div>
        <p className="mt-8 text-sm leading-6 text-gray-500">
          &copy; 2025 GoldTrade Global Ltd. Todos los derechos reservados. Las inversiones en trading conllevan riesgos y son operadas por profesionales para minimizar el impacto.
        </p>
      </div>
    </footer>
  );
}
