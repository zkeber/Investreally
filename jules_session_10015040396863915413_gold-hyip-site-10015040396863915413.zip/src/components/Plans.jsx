import { investmentPlans } from "../config/plans";

export default function Plans() {
  return (
    <div id="plans" className="bg-black py-24 sm:py-32 border-t border-gold/10">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-base font-semibold leading-7 text-gold">Planes de Inversión</h2>
          <p className="mt-2 text-4xl font-semibold tracking-tight text-white sm:text-5xl">
            Elija el plan que mejor se adapte a usted
          </p>
        </div>
        <div className="mx-auto mt-16 grid max-w-lg grid-cols-1 items-center gap-y-10 gap-x-8 sm:mt-20 lg:max-w-none lg:grid-cols-3">
          {investmentPlans.map((plan) => (
            <div
              key={plan.id}
              className={`flex flex-col justify-between rounded-3xl bg-zinc-900/50 p-8 ring-1 ring-gold/20 xl:p-10 hover:ring-gold/50 transition-all transform hover:-translate-y-2 group shadow-xl`}
            >
              <div>
                <div className="flex items-center justify-between gap-x-4">
                  <h3 className="text-2xl font-semibold leading-8 text-gold group-hover:text-gold-light">
                    {plan.name}
                  </h3>
                </div>
                <p className="mt-4 text-sm leading-6 text-gray-400">
                  {plan.duration} de rendimiento diario garantizado.
                </p>
                <p className="mt-6 flex items-baseline gap-x-1">
                  <span className="text-4xl font-bold tracking-tight text-white">{plan.percentage}</span>
                  <span className="text-sm font-semibold leading-6 text-gray-400">/{plan.period}</span>
                </p>
                <ul role="list" className="mt-8 space-y-3 text-sm leading-6 text-gray-300 xl:mt-10">
                  <li className="flex gap-x-3">
                    <span className="text-gold">✓</span> Mínimo: ${plan.min}
                  </li>
                  <li className="flex gap-x-3">
                    <span className="text-gold">✓</span> Máximo: ${plan.max}
                  </li>
                  <li className="flex gap-x-3">
                    <span className="text-gold">✓</span> Retiros instantáneos
                  </li>
                  <li className="flex gap-x-3">
                    <span className="text-gold">✓</span> Soporte 24/7
                  </li>
                </ul>
              </div>
              <a
                href="#"
                className="mt-8 block rounded-md px-3 py-2 text-center text-sm font-semibold leading-6 bg-gold text-black shadow-sm hover:bg-gold-light focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold transition-colors"
              >
                Invertir Ahora
              </a>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
