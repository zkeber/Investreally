export default function Hero() {
  return (
    <div className="relative isolate px-6 pt-14 lg:px-8 bg-black">
      <div className="mx-auto max-w-2xl py-32 sm:py-48 lg:py-56">
        <div className="text-center">
          <h1 className="text-5xl font-extrabold tracking-tight text-gold sm:text-7xl mb-6">
            Inversión en Oro Respaldada por Expertos
          </h1>
          <p className="mt-8 text-lg font-medium text-pretty text-gray-400 sm:text-xl/8">
            En GoldTrade, garantizamos tus rendimientos mediante operaciones de trading profesionales en el mercado del oro. Nuestro equipo de expertos gestiona tu capital con estrategias probadas para asegurar ganancias consistentes.
          </p>
          <div className="mt-10 flex items-center justify-center gap-x-6">
            <a
              href="#plans"
              className="rounded-md bg-gold px-8 py-4 text-lg font-bold text-black shadow-lg shadow-gold/20 hover:bg-gold-light focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold transition-all"
            >
              Comenzar a Invertir
            </a>
            <a href="#about" className="text-lg font-semibold leading-6 text-white hover:text-gold transition-colors">
              Leer más <span aria-hidden="true">→</span>
            </a>
          </div>
        </div>
      </div>
      <div className="absolute inset-x-0 -z-10 transform-gpu overflow-hidden blur-3xl" aria-hidden="true">
        <div className="relative left-[calc(50%-11rem)] aspect-[1155/678] w-[36.125rem] -translate-x-1/2 rotate-[30deg] bg-gradient-to-tr from-[#d4af37] to-[#996515] opacity-20 sm:left-[calc(50%-30rem)] sm:w-[72.1875rem]"></div>
      </div>
    </div>
  )
}
