export default function Header() {
  return (
    <nav className="flex items-center justify-between p-6 bg-black border-b border-gold/30">
      <div className="flex items-center space-x-2">
        <span className="text-2xl font-bold text-gold">GoldTrade</span>
      </div>
      <div className="hidden md:flex space-x-8 text-sm uppercase tracking-widest text-gray-400">
        <a href="#" className="hover:text-gold transition-colors">Inicio</a>
        <a href="#plans" className="hover:text-gold transition-colors">Planes</a>
        <a href="#about" className="hover:text-gold transition-colors">Nosotros</a>
        <a href="#" className="hover:text-gold transition-colors">Soporte</a>
      </div>
      <div className="flex space-x-4">
        <button className="px-4 py-2 text-sm font-semibold text-gold border border-gold rounded-full hover:bg-gold hover:text-black transition-all">Acceder</button>
        <button className="px-4 py-2 text-sm font-semibold bg-gold text-black rounded-full hover:bg-gold-light transition-all shadow-lg shadow-gold/20">Registrarse</button>
      </div>
    </nav>
  )
}
