import Header from './components/Header'
import Hero from './components/Hero'
import Plans from './components/Plans'
import Footer from './components/Footer'
import './App.css'

function App() {
  return (
    <div className="min-h-screen bg-black text-white font-sans selection:bg-gold selection:text-black">
      <Header />
      <main>
        <Hero />
        <section id="about" className="bg-zinc-900 py-24 sm:py-32">
          <div className="mx-auto max-w-7xl px-6 lg:px-8">
            <div className="mx-auto max-w-2xl lg:text-center">
              <h2 className="text-base font-semibold leading-7 text-gold">Operaciones Profesionales</h2>
              <p className="mt-2 text-3xl font-bold tracking-tight text-white sm:text-4xl">
                ¿Cómo generamos sus beneficios?
              </p>
              <p className="mt-6 text-lg leading-8 text-gray-400">
                A diferencia de otras plataformas, nuestro capital es gestionado por traders certificados con años de experiencia en el mercado de materias primas, específicamente en el oro. Utilizamos análisis técnico avanzado y gestión de riesgo institucional para asegurar que cada centavo de su inversión sea rentabilizado.
              </p>
            </div>
            <div className="mx-auto mt-16 max-w-2xl sm:mt-20 lg:mt-24 lg:max-w-4xl">
              <dl className="grid max-w-xl grid-cols-1 gap-x-8 gap-y-10 lg:max-w-none lg:grid-cols-2 lg:gap-y-16">
                <div className="relative pl-16">
                  <dt className="text-base font-semibold leading-7 text-white">
                    <div className="absolute left-0 top-0 flex h-10 w-10 items-center justify-center rounded-lg bg-gold text-black font-bold">
                      1
                    </div>
                    Análisis Fundamental
                  </dt>
                  <dd className="mt-2 text-base leading-7 text-gray-400">Evaluamos las tendencias económicas globales para predecir movimientos en el precio del oro.</dd>
                </div>
                <div className="relative pl-16">
                  <dt className="text-base font-semibold leading-7 text-white">
                    <div className="absolute left-0 top-0 flex h-10 w-10 items-center justify-center rounded-lg bg-gold text-black font-bold">
                      2
                    </div>
                    Gestión de Riesgo
                  </dt>
                  <dd className="mt-2 text-base leading-7 text-gray-400">Nunca arriesgamos más del 1% del capital total en una sola operación.</dd>
                </div>
                <div className="relative pl-16">
                  <dt className="text-base font-semibold leading-7 text-white">
                    <div className="absolute left-0 top-0 flex h-10 w-10 items-center justify-center rounded-lg bg-gold text-black font-bold">
                      3
                    </div>
                    Transparencia Total
                  </dt>
                  <dd className="mt-2 text-base leading-7 text-gray-400">Informes diarios de rendimiento y auditorías externas regulares.</dd>
                </div>
                <div className="relative pl-16">
                  <dt className="text-base font-semibold leading-7 text-white">
                    <div className="absolute left-0 top-0 flex h-10 w-10 items-center justify-center rounded-lg bg-gold text-black font-bold">
                      4
                    </div>
                    Retiros Prioritarios
                  </dt>
                  <dd className="mt-2 text-base leading-7 text-gray-400">Sus ganancias están disponibles para retiro de forma expedita y segura.</dd>
                </div>
              </dl>
            </div>
          </div>
        </section>
        <Plans />
      </main>
      <Footer />
    </div>
  )
}

export default App
