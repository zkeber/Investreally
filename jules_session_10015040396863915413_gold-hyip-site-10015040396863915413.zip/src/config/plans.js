export const investmentPlans = [
  {
    id: 1,
    name: "Plan Bronce",
    percentage: "1.5%",
    period: "Diario",
    min: "100",
    max: "1,000",
    duration: "30 días",
  },
  {
    id: 2,
    name: "Plan Oro",
    percentage: "2.5%",
    period: "Diario",
    min: "1,001",
    max: "5,000",
    duration: "45 días",
  },
  {
    id: 3,
    name: "Plan Platino",
    percentage: "4.0%",
    period: "Diario",
    min: "5,001",
    max: "50,000",
    duration: "60 días",
  },
];
